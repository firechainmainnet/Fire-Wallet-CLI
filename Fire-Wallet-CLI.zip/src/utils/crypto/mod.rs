// 🔐 Módulo intermediário de criptografia FireChain
// Expondo a subcamada de algoritmos simétricos AES-GCM

pub mod aes;
